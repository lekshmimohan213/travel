from django.db import models

from complaint.models import Complaint


class Solution(models.Model):
    answer = models.TextField()
    complaint = models.ForeignKey(Complaint, on_delete=models.CASCADE)
    status = models.BooleanField(default=True)

    def __str__(self):
        return self.answer
