from django import forms
from .models import Solution


class SolutionCreate(forms.ModelForm):
    class Meta:
        model = Solution
        fields = '__all__'

    def __init__(self, *args, **kwargs):
        super(SolutionCreate, self).__init__(*args, **kwargs)
        self.fields["complaint"].empty_label = "select"
        self.fields["complaint"].required = False
