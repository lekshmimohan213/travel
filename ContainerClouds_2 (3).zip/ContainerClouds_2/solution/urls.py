from django.urls import path
from . import views
from abclibrary.settings import DEBUG, STATIC_URL, STATIC_ROOT, MEDIA_URL, MEDIA_ROOT
from django.conf.urls.static import static

urlpatterns = [
    path('all', views.solution_all, name='solution_all'),
    path('uploadsolution/', views.upload, name='upload_solution'),
    path('uploadsolution/<int:solution_id>', views.update_solution, name='update_solution'),
    path('delete/<int:solution_id>', views.delete_solution, name='delete_solution'),
]

if DEBUG:
    urlpatterns += static(STATIC_URL, document_root=STATIC_ROOT)
    urlpatterns += static(STATIC_URL, document_root=MEDIA_ROOT)
