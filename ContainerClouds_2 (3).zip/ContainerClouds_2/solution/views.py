

from django.shortcuts import render, redirect
from .models import Solution
from .form import SolutionCreate
from django.http import HttpResponse


# Create your views here.


def solution_all(request):
    solution = Solution.objects.all()
    return render(request, 'allsolutions.html', {'solution': solution})


def upload(request):
    upload = SolutionCreate()
    if request.method == 'POST':
        upload = SolutionCreate(request.POST, request.FILES)
        if upload.is_valid():
            upload.save()
            return redirect('solution_all')
        else:
            return HttpResponse(""" Something went wrong click <a href= "{{url: 'solution_all'}}">Reload</a>""")
    else:
        return render(request, 'upload_form.html', {'upload_form': upload})  #need to change


def update_solution(request, solution_id):
    solution_id = int(solution_id)
    try:
        solution_shelf = Solution.objects.get(id=solution_id)
    except Solution.DoesNotExist:
        return redirect('solution_all')
    solution_form = SolutionCreate(request.POST or None, instance=solution_shelf)
    if solution_form.is_valid():
        solution_form.save()
        return redirect('solution_all')
    return render(request, 'upload_form.html', {'upload_form': solution_form})


def delete_solution(request, solution_id):
    solution_id = int(solution_id)
    try:
        solution_shelf = Solution.objects.get(id=solution_id)
    except Solution.DoesNotExist:
        return redirect('solution_all')
    solution_shelf.delete()
    return redirect('solution_all')

