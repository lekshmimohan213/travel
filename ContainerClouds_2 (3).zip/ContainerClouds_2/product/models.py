from django.db import models

# Create your models here.
from company.models import Company


class Category(models.Model):
    name = models.CharField(max_length=50)

    def __str__(self):
        return self.name


class SubCategory(models.Model):
    subcategoryname = models.CharField(max_length=50)
    category = models.ForeignKey(Category, on_delete=models.CASCADE)

    def __str__(self):
        return self.subcategoryname


class Product(models.Model):
    productname = models.CharField(max_length=50)
    company = models.ForeignKey(Company, on_delete=models.CASCADE)
    image = models.ImageField(upload_to='pic')
    price = models.IntegerField()
    status = models.BooleanField(default=True)

    def __str__(self):
        return self.productname
