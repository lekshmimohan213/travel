from django.urls import path
from . import views
from abclibrary.settings import DEBUG, STATIC_URL, STATIC_ROOT, MEDIA_URL, MEDIA_ROOT
from django.conf.urls.static import static

urlpatterns = [
    path('all', views.product_all, name='product_all'),
    path('uploadproduct/', views.upload, name='upload_product'),
    path('uploadproduct/<int:product_id>', views.update_product, name='update_product'),
    path('delete/<int:product_id>', views.delete_product, name='delete_product'),
]

if DEBUG:
    urlpatterns += static(STATIC_URL, document_root=STATIC_ROOT)
    urlpatterns += static(STATIC_URL, document_root=MEDIA_ROOT)
