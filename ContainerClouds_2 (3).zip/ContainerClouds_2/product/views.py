

from django.shortcuts import render, redirect
from .models import Product
from .form import ProductCreate
from django.http import HttpResponse


# Create your views here.


def product_all(request):
    product = Product.objects.all()
    return render(request, 'allproducts.html', {'product': product})


def upload(request):
    upload = ProductCreate()
    if request.method == 'POST':
        upload = ProductCreate(request.POST, request.FILES)
        if upload.is_valid():
            upload.save()
            return redirect('product_all')
        else:
            return HttpResponse(""" Something went wrong click <a href= "{{url: 'product_all'}}">Reload</a>""")
    else:
        return render(request, 'upload_form.html', {'upload_form': upload})  #need to change


def update_product(request, product_id):
    product_id = int(product_id)
    try:
        product_shelf = Product.objects.get(id=product_id)
    except Product.DoesNotExist:
        return redirect('product_all')
    product_form = ProductCreate(request.POST or None, instance=product_shelf)
    if product_form.is_valid():
        product_form.save()
        return redirect('product_all')
    return render(request, 'upload_form.html', {'upload_form': product_form})


def delete_product(request, product_id):
    product_id = int(product_id)
    try:
        product_shelf = Product.objects.get(id=product_id)
    except Product.DoesNotExist:
        return redirect('product_all')
    product_shelf.delete()
    return redirect('product_all')

