from django import forms
from .models import Product


class ProductCreate(forms.ModelForm):
    class Meta:
        model = Product
        fields = '__all__'

    def __init__(self, *args, **kwargs):
        super(ProductCreate, self).__init__(*args, **kwargs)
        self.fields["company"].empty_label = "select"
        self.fields["company"].required = False
