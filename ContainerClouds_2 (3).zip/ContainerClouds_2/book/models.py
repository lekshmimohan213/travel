from django.db import models

# Create your models here.
from company.models import TicketSeller
from staff.models import Staff


class Book(models.Model):
    filename = models.CharField(max_length=50)
    file = models.FileField(upload_to='pic')
    description = models.TextField(default="this is a dummy text")

    def __str__(self):
        return self.filename


class FileDtls(models.Model):
    filename = models.CharField(max_length=50)
    file = models.FileField(upload_to='pic')
    description = models.TextField(default="this is a dummy text")
    ticketseller = models.ForeignKey(TicketSeller, on_delete=models.CASCADE)

    def __str__(self):
        return self.filename


class FileAccess(models.Model):
    book = models.ForeignKey(FileDtls, on_delete=models.CASCADE)
    uid = models.ForeignKey(Staff, on_delete=models.CASCADE)
    key = models.CharField(max_length=150)
    status = models.BooleanField(default=False)
    policy =models.CharField(max_length=150,default="single")
