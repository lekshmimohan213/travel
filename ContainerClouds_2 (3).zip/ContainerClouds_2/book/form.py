from django import forms
from .models import Book, FileDtls


class BookCreate(forms.ModelForm):
    class Meta:
        model = Book
        fields = '__all__'
        # exclude = ['ticketseller']


class FileDtlsCreate(forms.ModelForm):
    class Meta:
        model = FileDtls
        fields = '__all__'
        exclude = ['ticketseller']
