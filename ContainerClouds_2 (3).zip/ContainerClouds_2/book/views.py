import os
import string
from django.core.files import File
from django.conf import Settings, settings
from django.contrib import messages
from django.shortcuts import render, redirect
import random
from book import security
from company.models import TicketSeller
from staff.models import Staff, StaffKey
from .models import Book, FileAccess, FileDtls
from .form import BookCreate, FileDtlsCreate
from django.http import HttpResponse, Http404


# Create your views here.
# Import mimetypes module
import mimetypes
# import os module
import os
# Import HttpResponse module
from django.http.response import HttpResponse


def download_file(request,path):
    # Define Django project base directory
    # BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    # # Define text file name
    # filename = 'test.txt'
    # # Define the full file path
    # filepath = BASE_DIR + '/filedownload/Files/' + filename
    # Open the file for reading content
    access_id = int(path)
    customer_shelf = FileAccess.objects.get(id=access_id)
    path = customer_shelf.book.file.name
    path = path[4:]
    filename = path
    path = "pic\\decrypt\\\pic\\" + path
    filepath = os.path.join(settings.MEDIA_ROOT, path)
    path = open(filepath, 'r')
    # Set the mime type
    mime_type, _ = mimetypes.guess_type(filepath)
    # Set the return value of the HttpResponse
    response = HttpResponse(path, content_type=mime_type)
    # Set the HTTP header for sending to browser
    response['Content-Disposition'] = "attachment; filename=%s" % filename
    # Return the response value
    return response







def download(request, path):
    access_id = int(path)
    customer_shelf = FileAccess.objects.get(id=access_id)
    path = customer_shelf.book.file.name
    path = path[4:]
    path = "pic\\decrypt\\" + path
    file_path = os.path.join(settings.MEDIA_ROOT, path)
    print(file_path)
    if os.path.exists(file_path):
        with open(file_path, 'rb') as fh:
            response = HttpResponse(fh.read(), content_type="application/vnd.txt")
            response['Content-Disposition'] = 'inline; filename=' + os.path.basename(file_path)
            return response
    raise Http404

def index(request):
    return render(request, 'master.html')


def books_all(request):
    books = FileDtls.objects.all()
    return render(request, 'books.html', {'shelf': books, 'title': 'View All Files'})


def books_staff_all(request):
    try:
        uid = int(request.session['member_id'])
        ticketseller = TicketSeller.objects.filter(id=uid).first()
        books = FileDtls.objects.filter(ticketseller=ticketseller)

        filename_1 = os.path.join(settings.BASE_DIR, 'media\\')
        return render(request, 'viewbooks2.html', {'shelf': books, 'path': filename_1})
    except Exception as e:
        return render(request, 'viewbooks2.html', {'shelf': books, 'path': filename_1})


def books_access(request, book_id):
    book_id = int(book_id)
    books = FileDtls.objects.get(id=book_id)
    uid = request.session['member_id']
    staff = Staff.objects.get(id=uid)
    source = string.ascii_letters + string.digits
    result_str = ''.join((random.choice(source) for i in range(8)))
    frm = FileAccess(book=books, uid=staff, key=result_str)
    frm.save()
    messages.success(request, 'Access Request Send')
    return redirect('books_all')
    # return render(request, 'books.html', {'shelf': books})


def books_hve_access(request):
    uid = request.session['member_id']
    book_shelf = FileAccess.objects.filter(uid_id=uid)
    # print(book_shelf.status)
    return render(request, 'filesaccess.html', {'shelf': book_shelf, "title": "Requested Files"})


def books_staff_acess(request,book_id):
    try:
        book_id = int(book_id)
        book_shelf = FileAccess.objects.filter(book_id=book_id)
        return render(request, 'processrequest.html', {'shelf': book_shelf,"title": " Files Requested" })
    except Exception as e:
        return render(request, 'processrequest.html', {'shelf': book_shelf})

def permit_user(request, reqid):
    reqid = int(reqid)
    book_shelf = FileAccess.objects.filter(id=reqid).first()
    if request.method == 'POST':
        policy=request.POST.get('policy')
        book_shelf.status = True
        book_shelf.policy=policy
        book_shelf.save(update_fields=['status','policy'])
    return render(request, 'setaccesspolicy.html', {'shelf': book_shelf})



def books_staff_ticket(request):
    try:
        uid = int(request.session['member_id'])
        ticketseller = TicketSeller.objects.filter(id=uid).first()
        books = FileDtls.objects.filter(ticketseller=ticketseller)

        filename_1 = os.path.join(settings.BASE_DIR, 'media\\')
        return render(request, 'bookrequested.html', {'shelf': books, 'path': filename_1})
    except Exception as e:
        return render(request, 'bookrequested.html', {'shelf': books, 'path': filename_1})




    # try:
    #     # if request.method != 'POST':
    #     uid = int(request.session['member_id'])
    #     print(uid)
    #     ticketseller = TicketSeller.objects.filter(id=uid).first()
    #     #books = FileDtls.objects.filter(ticketseller=ticketseller)
    #     book_list_requested = []
    #     book_shelf = FileAccess.objects.all()
    #     for fileacc in book_shelf:
    #         if fileacc.book.ticketseller == ticketseller:
    #             book_list_requested.append(fileacc)
    #     return render(request, 'bookrequested.html', {'shelf': book_list_requested})
    #     # accesspolicy = request.POST.get('accesspolicy')
    #     # print(accesspolicy)
    #     #return redirect('books_staff_all')
    # except Exception as e:
    #     print('haiiii')
    #     return redirect('books_staff_all')
    # cid = str(customer_shelf.id)
    # key = base64Encode("staff" + cid)
    # customer_shelf.status = not customer_shelf.status
    # customer_shelf.save(update_fields=['status'])
    # f = open("demofile3.txt", "w")
    # f.write("Your Key Is " + key)
    # f.close()
    # return redirect('staff_all')


def update_key_message(request, book_id):
    access_id = int(book_id)
    customer_id = request.session['member_id']
    customer_shelf = FileAccess.objects.get(id=access_id)
    if request.method == 'POST':
        book_id = request.POST.get('book_id')
        key = request.POST.get('key')

        if key != customer_shelf.key:
            messages.error(request, 'Key Mismatch')
            return render(request, 'decrypt.html', {'book_id': book_id})
        else:
            book = FileDtls.objects.get(id=customer_shelf.book_id)
            #book_id = book.id
            print(book.description)
            description = security.base64Decode(book.description)
            # description = book.description
            path = book.file.name
            file_path = os.path.join(settings.MEDIA_ROOT, path)
            print(path)
            security.decrypt(path)
            path = book.file.name
            path = path[4:]
            #path = "pic\\decrypt\\" + path
            file_path = os.path.join(settings.MEDIA_ROOT, path)
            #book.file.name = file_path
            return render(request, 'download.html',
                          {'book_id': book_id, 'file_path':access_id, 'description': description})
            # file_path = os.path.join(settings.MEDIA_ROOT, path)
            # if os.path.exists(file_path):
            #     with open(file_path, 'rb') as fh:
            #         response = HttpResponse(fh.read(), content_type="application/vnd.ms-excel")
            #         response['Content-Disposition'] = 'inline; filename=' + os.path.basename(file_path)
            #         return response
            # raise Http404
        # customer_id = request.session['member_id']
        # customer_shelf = Customer.objects.get(id=customer_id)
        # print(key)
    return render(request, 'decrypt.html', {'book_id': access_id, 'orkey': customer_shelf.key})


def upload(request):
    upload = FileDtlsCreate()
    if request.method == 'POST':
        upload = FileDtlsCreate(request.POST, request.FILES)
        if upload.is_valid():
            filename = upload.cleaned_data['filename']
            file = upload.cleaned_data['file'].name
            frm = upload.cleaned_data['file']
            filename_1 = os.path.join(settings.BASE_DIR, 'media\\pic\\' + file)
            description = upload.cleaned_data['description']
            # print(file)
            description = security.base64Encode(description)
            id = int(request.session['member_id'])
            ticketseller = TicketSeller.objects.filter(id=id).first()
            frm1 = FileDtls(filename=filename, file=frm, description=description, ticketseller=ticketseller)
            frm1.save()
            security.encrypt(file)
            messages.success(request, 'File uploaded...')

            return redirect('books_staff_all')
        else:
            return HttpResponse(""" Something went wrong click <a href= "{{url: 'index'}}">Reload</a>""")
    else:
        return render(request, 'upload_form.html', {'upload_form': upload, "title": "Upload"})


def update_book(request, book_id):
    book_id = int(book_id)
    try:
        book_shelf = Book.objects.get(id=book_id)
    except Book.DoesNotExist:
        return redirect('index')
    book_form = BookCreate(request.POST or None, instance=book_shelf)
    if book_form.is_valid():
        book_form.save()
        return redirect('index')
    return render(request, 'upload_form.html', {'upload_form': book_form})


def delete_book(request, book_id):
    book_id = int(book_id)
    try:
        book_shelf = Book.objects.get(id=book_id)
    except Book.DoesNotExist:
        return redirect('index')
    book_shelf.delete()
    return redirect('index')
