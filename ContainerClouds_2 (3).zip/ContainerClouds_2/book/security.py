import os

from cryptography.fernet import Fernet
from django.conf import settings

filename_1 = os.path.join(settings.BASE_DIR,'media\\pic\\')

def write_key():
    """
    Generates a key and save it into a file
    """
    key = Fernet.generate_key()
    with open("key.key", "wb") as key_file:
        key_file.write(key)

def load_key():
    """
    Loads the key from the current directory named `key.key`
    """
    return open("key.key", "rb").read()

def encrypt(filename):
    """
    Given a filename (str) and key (bytes), it encrypts the file and write it
    """
    filename=filename_1+filename
    key=load_key()
    f = Fernet(key)
    with open(filename, "rb") as file:
        # read all file data
        file_data = file.read()
    # encrypt data
    encrypted_data = f.encrypt(file_data)
    # write the encrypted file
    with open(filename, "wb") as file:
        file.write(encrypted_data)

def decrypt(filename):
    """
    Given a filename (str) and key (bytes), it decrypts the file and write it
    """
    decrypt=filename
    filename_2 = os.path.join(settings.BASE_DIR, 'media\\')
    filename =filename_2+filename
    key = load_key()
    f = Fernet(key)
    with open(filename, "rb") as file:
        # read the encrypted data
        encrypted_data = file.read()
    # decrypt data
    decrypted_data = f.decrypt(encrypted_data)
    # write the original file
    filename_2 = filename_2 + "\\pic\\decrypt\\"
    filename = filename_2 + decrypt

    f = open(filename, "w")
    f.write("hi")
    f.close()
    with open(filename, "wb") as file:
        file.write(decrypted_data)

#write_key()
#key = load_key()

#print(key)
# file name
# file = "media/pic/data_test.csv"
# encrypt it
# encrypt(file)

# decrypt the file
#decrypt(file, key)


# generate and write a new key


#write_key()

def encryptText(msg):
	message = msg.encode()
	key=load_key()
# initialize the Fernet class
	f = Fernet(key)
# encrypt the message
	encrypted = f.encrypt(message)
	return(encrypted)

def decryptText(encrymsg):
    key = load_key()
    f = Fernet(key)
    decrypted_encrypted = f.decrypt(encrymsg)
    return(decrypted_encrypted)

#encryptText('some secret message');



import base64
def base64Encode(message):
	message_bytes = message.encode('ascii')
	base64_bytes = base64.b64encode(message_bytes)
	base64_message = base64_bytes.decode('ascii')
	return(base64_message)



def base64Decode(base64_message):
	base64_bytes = base64_message.encode('ascii')
	message_bytes = base64.b64decode(base64_bytes)
	message = message_bytes.decode('ascii')
	return(message)

# msg =input('enter the text to encode ')
# msg1=base64Encode(msg)
# print(msg1)
# msg2=base64Decode(msg1)
# print(f"original message {msg2}")