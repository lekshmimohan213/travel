from django.urls import path
from . import views
from abclibrary.settings import DEBUG, STATIC_URL, STATIC_ROOT, MEDIA_URL, MEDIA_ROOT
from django.conf.urls.static import static

urlpatterns = [
    path('admin/', views.admin_login, name='admin_login'),
    path('company/', views.company_login, name='company_login'),
    path('customer/', views.customer_login, name='customer_login'),
    path('staff/', views.staff_login, name='staff_login'),
    # path('customer/', views.customer_login, name='upload_staff'),
    # path('staff/', views.staff_login, name='company_login'),
    path('logout/', views.logout, name='logout'),
]

if DEBUG:
    urlpatterns += static(STATIC_URL, document_root=STATIC_ROOT)
    urlpatterns += static(STATIC_URL, document_root=MEDIA_ROOT)
