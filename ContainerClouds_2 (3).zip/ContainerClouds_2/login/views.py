from django.contrib import messages
from django.shortcuts import render, redirect
from django.http import HttpResponse
# Create your views here.
from book.security import base64Encode
from company.models import Company, TicketSeller
from customer.models import Customer
from login.models import Admin
from staff.models import Staff
#from django.contrib.auth.hashers import make_password
from hashlib import sha256
def admin_login(request):
    if request.method != 'POST':
        # raise Http404('Only POSTs are allowed')
        return render(request, 'adminlogin.html')
    try:
        m = Admin.objects.get(username=request.POST['username'])

        pass1 =request.POST['password']
        #password = make_password(pass1)
        password = sha256(pass1.encode()).hexdigest()
        # print(request.POST['username'])
        # print(pass1)
        # print(password)
        # print(m.password)
        if m.password == password:
            request.session['member_id'] = m.id
            request.session['member_type'] = 'admin'
            return render(request, 'companyhome.html')
            # return HttpResponseRedirect('/you-are-logged-in/')
        else:
            return HttpResponse(
                "<div style='margin-left:15%;margin-top:15%' >Your username and password didn't match.<a href='' %}'>CLICK HERE TO GO BACK</a></div>")
    except Admin.DoesNotExist:
        return HttpResponse("<div style='margin-left:15%;margin-top:15%' >Invalid username <a href='' %}'>CLICK HERE TO GO BACK</a></div>")

def company_login(request):
    if request.method != 'POST':
        # raise Http404('Only POSTs are allowed')
        return render(request, 'companylogin.html')
    try:
        m = TicketSeller.objects.get(username=request.POST['username'])
        if not m.status:
            return HttpResponse(
                "<div style='margin-left:15%;margin-top:15%' >Your Group Namae Is Not Set Please Wait..<a href='' %}'>CLICK HERE TO GO BACK</a></div>")

        if m.password == request.POST['password']:
            privatekey = request.POST['privatekey']
            cid = str(m.id)
            actulkey = base64Encode("tseller" + cid)
            if actulkey != privatekey:
                messages.error(request, 'Wrong Privte Key')
                return render(request, 'companylogin.html')
            request.session['member_id'] = m.id
            request.session['member_type'] = 'company'
            request.session['fname'] = m.firstname
            return render(request, 'companyhome.html')
            # return HttpResponseRedirect('/you-are-logged-in/')
        else:
            return HttpResponse(
                "<div style='margin-left:15%;margin-top:15%' >Your username and password didn't match.<a href='' %}'>CLICK HERE TO GO BACK</a></div>")
    except Company.DoesNotExist:
        return HttpResponse(
            "<div style='margin-left:15%;margin-top:15%' >Invalid username...<a href='' %}'>CLICK HERE TO GO BACK</a></div>")


def customer_login(request):
    if request.method != 'POST':
        # raise Http404('Only POSTs are allowed')
        return render(request, 'customerlogin.html')
    try:
        m = Customer.objects.get(username=request.POST['username'])
        if m.password == request.POST['password']:
            request.session['member_id'] = m.id
            request.session['member_type'] = 'customer'
            return render(request, 'companyhome.html')
            # return HttpResponseRedirect('/you-are-logged-in/')
        else:
            return HttpResponse(
                "<div style='margin-left:15%;margin-top:15%' >Your username and password didn't match.<a href='' %}'>CLICK HERE TO GO BACK</a></div>")
    except Customer.DoesNotExist:
        return HttpResponse("Your username and password didn't match.")


def staff_login(request):
    if request.method != 'POST':
        # raise Http404('Only POSTs are allowed')
        return render(request, 'stafflogin.html')
    try:
        m = Staff.objects.get(username=request.POST['username'])
        if m.password == request.POST['password']:
            if not m.status:
                return HttpResponse(
                    "<div style='margin-left:15%;margin-top:15%' >Your Acces Has been Revoked.....<a href='' %}'>CLICK HERE TO GO BACK</a></div>")
            privatekey = request.POST['privatekey']
            cid = str(m.id)
            actulkey = base64Encode("staff" + cid)
            if actulkey != privatekey:
                messages.error(request, 'Wrong Privte Key')
                return render(request, 'stafflogin.html')
            request.session['member_id'] = m.id
            request.session['member_type'] = 'staff'
            request.session['fname'] = m.firstname
            #request.session['com_id'] = m.company_id
            return render(request, 'companyhome.html')
            # return HttpResponseRedirect('/you-are-logged-in/')
        else:
            return HttpResponse(
                "<div style='margin-left:15%;margin-top:15%' >Your username and password didn't match.<a href='' %}'>CLICK HERE TO GO BACK</a></div>")
    except Staff.DoesNotExist:
        return HttpResponse(
            "<div style='margin-left:15%;margin-top:15%' >Invalid username...<a href='' %}'>CLICK HERE TO GO BACK</a></div>")


def logout(request):
    try:
        del request.session['member_id']
        del request.session['member_type']
        del request.session['com_id']
        del request.session['fname']
    except KeyError:
        pass
    return redirect('index')
