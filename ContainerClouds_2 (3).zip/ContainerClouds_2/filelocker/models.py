from django.db import models

# Create your models here.
class FileLocker(models.Model):
    filename = models.CharField(max_length=50)
    file = models.FileField(upload_to='pic')
    title = models.CharField(max_length=20)
    details = models.TextField()
    status = models.BooleanField(default=True)

    def __str__(self):
        return self.companyname