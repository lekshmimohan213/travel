from django.shortcuts import render, redirect
from .models import Customer
from .form import CustomerCreate
from django.http import HttpResponse
from django.contrib import messages

# Create your views here.

def customer_all(request):
    customer = Customer.objects.all()
    return render(request, 'allcustomer.html', {'customer': customer, 'title': ' Staff List'})


def upload(request):
    upload = CustomerCreate()
    if request.method == 'POST':
        upload = CustomerCreate(request.POST, request.FILES)
        if upload.is_valid():
            upload.save()
            messages.success(request, 'New Staff Created')
            return redirect('customer_all')
        else:
            return HttpResponse(""" Something went wrong click <a href= "{{url: 'customer_all'}}">Reload</a>""")
    else:
        return render(request, 'newcustomer.html', {'upload_form': upload,'title': ' New Staff'})


def update_customer(request, customer_id):
    customer_id = int(customer_id)
    try:
        customer_shelf = Customer.objects.get(id=customer_id)
    except Customer.DoesNotExist:
        return redirect('customer_all')
    customer_form = CustomerCreate(request.POST or None, instance=customer_shelf)
    if customer_form.is_valid():
        customer_form.save()
        messages.success(request, 'Staff Removed')
        return redirect('customer_all')
    return render(request, 'newcustomer.html', {'upload_form': customer_form, 'title': ' Edit Staff'})


def delete_customer(request, customer_id):
    customer_id = int(customer_id)
    try:
        customer_shelf = Customer.objects.get(id=customer_id)
    except Customer.DoesNotExist:
        return redirect('customer_all')
    customer_shelf.delete()
    return redirect('customer_all')
