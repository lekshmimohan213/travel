from django.urls import path
from . import views
from abclibrary.settings import DEBUG, STATIC_URL, STATIC_ROOT, MEDIA_URL, MEDIA_ROOT
from django.conf.urls.static import static

urlpatterns = [
    path('newcomplaints', views.upload, name='upload_complaint'),
    path('customcomplaint', views.upload_custom, name='upload_custon_complaint'),
    path('uploadcomplaints/<int:complaints_id>', views.update_complaints, name='update_complaints'),
    # path('delete/<int:staff_id>', views.delete_staff, name='update_staff'),
    path('allcomplaints/<int:company_id>', views.complaint_all, name='complaint_all'),  #view company wise
    path('cutomcomplaint/<int:customer_id>', views.cutomcomplaint_all, name='cutomcomplaint'),  # view customer wise
    # path('uploadcomplaint/', views.upload, name='upload_complaint'),  #to add complaint
    # path('uploadcomplaint/<int:complaint_id>', views.update_complaint, name='update_complaint'),  #modify
    # path('delete/<int:complaint_id>', views.delete_complaint, name='delete_complaint'),

    path('ajax/load_products/', views.load_products, name='ajax_load_products'),  # AJAX
]

if DEBUG:
    urlpatterns += static(STATIC_URL, document_root=STATIC_ROOT)
    urlpatterns += static(STATIC_URL, document_root=MEDIA_ROOT)
