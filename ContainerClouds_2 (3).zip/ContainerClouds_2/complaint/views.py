from django.http import HttpResponse
from django.shortcuts import render, redirect
from .form import ComplaintCreate
from .models import Complaint


# path('all/<int:company_id>', views.product_all, name='product_all'),  # view company wise
# path('cutomcomplaint/<int:customer_id>', views.cutomcomplaint_all, name='cutomcomplaint'),  # view customer wise
# path('uploadcomplaint/', views.upload, name='upload_complaint'),  # to add complaint
# path('uploadcomplaint/<int:complaint_id>', views.update_complaint, name='update_complaint'),  # modify
# path('delete/<int:complaint_id>', views.delete_complaint, name='delete_complaint'),


# Create your views here.


def complaint_all(request, company_id):
    complaint = Complaint.objects.filter(company_id=company_id)
    return render(request, 'allcomplaints.html', {'complaint': complaint})


def cutomcomplaint_all(request, customer_id):
    complaint = Complaint.objects.filter(customer_id=customer_id)
    return render(request, 'allcomplaints.html', {'complaint': complaint})


def upload(request):
    upload = ComplaintCreate()
    if request.method == 'POST':
        upload = ComplaintCreate(request.POST, request.FILES)
        if upload.is_valid():
            upload.save()
            return redirect('company_all')  # redirect to company list actually to user home
        else:
            return HttpResponse(""" Something went wrong click <a href= "{{url: 'company_all'}}">Reload</a>""")
    else:
        return render(request, 'upload_form.html', {'upload_form': upload})  # need to change


def upload_custom(request):
    upload = ComplaintCreate()
    if request.method == 'POST':
        upload = ComplaintCreate(request.POST, request.FILES)
        if upload.is_valid():
            upload.save()
            return redirect('company_all')  # redirect to company list actually to user home
        else:
            return HttpResponse(""" Something went wrong click <a href= "{{url: 'company_all'}}">Reload</a>""")
    else:
        return render(request, 'upload_form.html', {'upload_form': upload})  # need to change


def update_complaints(request, complaints_id):
    complaints_id = int(complaints_id)
    try:
        complaints_shelf = Complaint.objects.get(id=complaints_id)
    except Complaint.DoesNotExist:
        return redirect('company_all')
    complaints_form = ComplaintCreate(request.POST or None, instance=complaints_shelf)
    if complaints_form.is_valid():
        complaints_form.save()
        return redirect('company_all')
    return render(request, 'upload_form.html', {'upload_form': complaints_form})


# def delete_product(request, product_id):
#     product_id = int(product_id)
#     try:
#         product_shelf = Product.objects.get(id=product_id)
#     except Product.DoesNotExist:
#         return redirect('product_all')
#     product_shelf.delete()
#     return redirect('product_all')


# AJAX
def load_products(request):
    country_id = request.GET.get('country_id')
    cities = City.objects.filter(country_id=country_id).all()
    return render(request, 'persons/city_dropdown_list_options.html', {'cities': cities})
    # return JsonResponse(list(cities.values('id', 'name')), safe=False)
