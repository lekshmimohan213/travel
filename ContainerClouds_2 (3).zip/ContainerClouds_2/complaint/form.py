from django import forms
from .models import Complaint


class ComplaintCreate(forms.ModelForm):

    class Meta:
        model = Complaint
        fields = '__all__'

    def __init__(self, *args, **kwargs):
        super(ComplaintCreate, self).__init__(*args, **kwargs)
        self.fields["company"].empty_label = "select"
        self.fields["company"].required = False
        self.fields["product"].empty_label = "select"
        self.fields["product"].required = False
        self.fields["customer"].empty_label = "select"
        self.fields["customer"].required = False