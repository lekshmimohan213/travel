from django.db import models
from company.models import Company
from product.models import Product
from customer.models import Customer


# Create your models here.

class Complaint(models.Model):
    subject = models.CharField(max_length=124)
    complainttext = models.TextField()
    company = models.ForeignKey(Company, on_delete=models.SET_NULL, blank=True, null=True)
    product = models.ForeignKey(Product, on_delete=models.SET_NULL, blank=True, null=True)
    customer = models.ForeignKey(Customer, on_delete=models.SET_NULL, blank=True, null=True)
    status = models.BooleanField(default=True)

    def __str__(self):
        return self.subject
