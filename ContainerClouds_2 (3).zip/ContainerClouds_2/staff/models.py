from django.db import models


# Create your models here.
from company.models import Company


class Staff(models.Model):
    firstname = models.CharField(max_length=50)
    #company = models.ForeignKey(Company, on_delete=models.CASCADE)
    email = models.EmailField()
    username = models.CharField(max_length=50)
    password = models.CharField(max_length=50)
    mob = models.CharField(max_length=12)
    status = models.BooleanField(default=False)


class StaffKey(models.Model):
    staff = models.ForeignKey(Staff, on_delete=models.CASCADE)
    key = models.CharField(max_length=10)


