from django import forms
from .models import Staff


class StaffCreate(forms.ModelForm):
    password = forms.CharField(widget=forms.PasswordInput)
    email = forms.EmailField()
    mob = forms.IntegerField(max_value=9999999999)

    class Meta:
        model = Staff
        fields = '__all__'
        exclude = ['status']


