import string

from django.shortcuts import render, redirect

from book.security import base64Encode
from .models import Staff, StaffKey
from .form import StaffCreate
from django.http import HttpResponse
import random
from django.contrib import messages


# Create your views here.


def staff_all(request):
    staff = Staff.objects.all()
    return render(request, 'allstaff.html', {'staff': staff, 'title': 'All Users'})


def approve_user(request, staff_id):
    customer_id = int(staff_id)
    try:
        customer_shelf = Staff.objects.get(id=customer_id)
    except Staff.DoesNotExist:
        return redirect('staff_all')
    cid = str(customer_shelf.id)
    key=base64Encode("staff"+cid)
    customer_shelf.status = not customer_shelf.status
    customer_shelf.save(update_fields=['status'])
    f = open("demofile3.txt", "w")
    f.write("Your Key Is "+key)
    f.close()
    return  redirect('staff_all')
    #return render(request, 'newcustomer.html', {'upload_form': customer_form, 'formname': ' Edit User'})



def upload(request):
    upload = StaffCreate()
    if request.method == 'POST':
        upload = StaffCreate(request.POST, request.FILES)
        if upload.is_valid():
            password = upload.cleaned_data['password']
            if not validatepssword(password):
                messages.error(request, 'Invalid Password')
                return redirect('upload_staff')
            upload.save()
            source = string.ascii_letters + string.digits
            result_str = ''.join((random.choice(source) for i in range(8)))
            staffid = upload.cleaned_data['username']
            staff_1 = Staff.objects.get(username=staffid)
            # print(staffid)
            # print(result_str)
            stf = StaffKey(staff=staff_1, key=result_str)
            stf.save()
            messages.success(request, 'New User Added')
            return redirect('staff_login')
        else:
            return HttpResponse(""" Something went wrong click <a href= "{{url: 'staff_login'}}">Reload</a>""")
    else:
        return render(request, 'upload_form.html',
                      {'upload_form': upload, "title": "Add New User Account"})  # need to change


def update_staff(request, staff_id):
    staff_id = int(staff_id)
    try:
        staff_shelf = Staff.objects.get(id=staff_id)
    except Staff.DoesNotExist:
        return redirect('staff_all')
    staff_form = StaffCreate(request.POST or None, instance=staff_shelf)
    if staff_form.is_valid():
        staff_form.save()
        return redirect('staff_all')
    return render(request, 'upload_form.html', {'upload_form': staff_form})


def delete_staff(request, staff_id):
    staff_id = int(staff_id)
    try:
        staff_shelf = Staff.objects.get(id=staff_id)
    except Staff.DoesNotExist:
        return redirect('staff_all')
    staff_shelf.delete()
    return redirect('staff_all')


def validatepssword(s):
    l, u, p, d = 0, 0, 0, 0
    # s = "R@m@_f0rtu9e$"
    capitalalphabets = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
    smallalphabets = "abcdefghijklmnopqrstuvwxyz"
    specialchar = "$@_"
    digits = "0123456789"
    if (len(s) >= 8):
        for i in s:

            # counting lowercase alphabets
            if (i in smallalphabets):
                l += 1

            # counting uppercase alphabets
            if (i in capitalalphabets):
                u += 1

            # counting digits
            if (i in digits):
                d += 1

            # counting the mentioned special characters
            if (i in specialchar):
                p += 1
    if (l >= 1 and u >= 1 and p >= 1 and d >= 1 and l + p + u + d == len(s)):
        return True
        # print("Valid Password")
    else:
        return False
        # print("Invalid Password")
