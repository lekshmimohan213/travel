from django.urls import path
from . import views
from abclibrary.settings import DEBUG, STATIC_URL, STATIC_ROOT, MEDIA_URL, MEDIA_ROOT
from django.conf.urls.static import static

urlpatterns = [
    path('all', views.staff_all, name='staff_all'),
    path('uploadstaff/', views.upload, name='upload_staff'),
    path('uploadstaff/<int:staff_id>', views.update_staff, name='update_staff'),
    path('delete/<int:staff_id>', views.delete_staff, name='update_staff'),
    path('approvetktseller/<int:staff_id>', views.approve_user, name='approve_user'),
]

if DEBUG:
    urlpatterns += static(STATIC_URL, document_root=STATIC_ROOT)
    urlpatterns += static(STATIC_URL, document_root=MEDIA_ROOT)
