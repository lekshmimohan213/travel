from django.shortcuts import render, redirect

from datamgnt.form import DataMgntCreate
from .models import DataMgnt
from django.http import HttpResponse
from django.contrib import messages


# Create your views here.

def datamgnt_all(request):
    datamgnt = DataMgnt.objects.all()
    return render(request, 'alldatamgnt.html', {'datamgnt': datamgnt, 'title': ' Staff List'})


def upload(request):
    upload = DataMgntCreate()
    if request.method == 'POST':
        upload = DataMgntCreate(request.POST, request.FILES)
        if upload.is_valid():
            upload.save()
            messages.success(request, 'New Staff Created')
            return redirect('datamgnt_all')
        else:
            return HttpResponse(""" Something went wrong click <a href= "{{url: 'datamgnt_all'}}">Reload</a>""")
    else:
        return render(request, 'newdatamgnt.html', {'upload_form': upload, 'title': ' File Uploaded'})


def update_datamgnt(request, datamgnt_id):
    datamgnt_id = int(datamgnt_id)
    try:
        datamgnt_shelf = DataMgnt.objects.get(id=datamgnt_id)
    except DataMgnt.DoesNotExist:
        return redirect('datamgnt_all')
    datamgnt_form = DataMgntCreate(request.POST or None, instance=datamgnt_shelf)
    if datamgnt_form.is_valid():
        datamgnt_form.save()
        messages.success(request, 'Staff Removed')
        return redirect('datamgnt_all')
    return render(request, 'newdatamgnt.html', {'upload_form': datamgnt_form, 'title': ' Edit File'})


def delete_datamgnt(request, datamgnt_id):
    datamgnt_id = int(datamgnt_id)
    try:
        datamgnt_shelf = DataMgnt.objects.get(id=datamgnt_id)
    except DataMgnt.DoesNotExist:
        return redirect('datamgnt_all')
    datamgnt_shelf.delete()
    return redirect('datamgnt_all')
