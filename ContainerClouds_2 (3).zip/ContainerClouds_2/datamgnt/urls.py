from django.urls import path
from . import views
from abclibrary.settings import DEBUG, STATIC_URL, STATIC_ROOT, MEDIA_URL, MEDIA_ROOT
from django.conf.urls.static import static

urlpatterns = [
    path('all', views.datamgnt_all, name='datamgnt_all'),
    path('uploaddatamgnt/', views.upload, name='upload_datamgnt'),
    path('uploaddatamgnt/<int:datamgnt_id>', views.update_datamgnt, name='update_datamgnt'),
    path('delete/<int:datamgnt_id>', views.delete_datamgnt, name='update_datamgnt'),
]

if DEBUG:
    urlpatterns += static(STATIC_URL, document_root=STATIC_ROOT)
    urlpatterns += static(STATIC_URL, document_root=MEDIA_ROOT)
