from django.apps import AppConfig


class DatamgntConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'datamgnt'
