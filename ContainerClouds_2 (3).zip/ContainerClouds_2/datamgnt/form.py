from django import forms
from .models import DataMgnt


class DataMgntCreate(forms.ModelForm):
    class Meta:
        model = DataMgnt
        fields = ['filename']
        labels = {'filename': 'Select File'}
        help_text = {'filename': 'Select File'}
        error_messages = {'filename': {'required': 'File required'}}
        #widgets = {'filename': forms.FileField}
