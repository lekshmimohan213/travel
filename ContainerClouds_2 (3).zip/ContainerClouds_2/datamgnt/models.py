from django.db import models
from customer.models import Customer


class DataMgnt(models.Model):
    filename = models.FileField(upload_to='pic')
    staff = models.ForeignKey(Customer, on_delete=models.CASCADE)
    status = models.BooleanField(default=True)

    def __str__(self):
        return self.filename
