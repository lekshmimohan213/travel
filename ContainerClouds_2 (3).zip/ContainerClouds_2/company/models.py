from django.db import models


# Create your models here.

class Company(models.Model):
    companyname = models.CharField(max_length=50)
    logo = models.ImageField(upload_to='pic')
    email = models.CharField(max_length=20)
    username = models.CharField(max_length=50)
    password = models.CharField(max_length=50)

    def __str__(self):
        return self.companyname


class TicketSeller(models.Model):
    firstname = models.CharField(max_length=50)
    image = models.ImageField(upload_to='pic')
    email = models.EmailField(max_length=25)
    username = models.CharField(max_length=50)
    password = models.CharField(max_length=50)
    mob = models.CharField(max_length=12)
    status = models.BooleanField(default=False)

    def __str__(self):
        return self.firstname


class Varifier(models.Model):
    username = models.CharField(max_length=50)
    password = models.CharField(max_length=50)