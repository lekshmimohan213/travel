from django.contrib import admin

# Register your models here.
from company.models import Company

admin.site.register(Company)
