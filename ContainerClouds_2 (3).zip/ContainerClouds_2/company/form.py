from django import forms
from .models import Company, TicketSeller


class CompanyCreate(forms.ModelForm):
    password = forms.CharField(widget=forms.PasswordInput)

    class Meta:
        model = Company
        fields = '__all__'



class CreateTicketSeller(forms.ModelForm):
    password = forms.CharField(widget=forms.PasswordInput)

    class Meta:
        model = TicketSeller
        fields = '__all__'
        exclude = ['status']