from django.urls import path
from . import views
from abclibrary.settings import DEBUG, STATIC_URL, STATIC_ROOT, MEDIA_URL, MEDIA_ROOT
from django.conf.urls.static import static

urlpatterns = [
    path('all', views.company_all, name='company_all'),
    path('admintrain', views.admin_train, name='admin_train'),
    path('admintrainsystem', views.admin_train_system, name='admin_train_system'),
    path('uploadcompany/', views.upload, name='upload_company'),
    path('uploadcompany/<int:company_id>', views.update_company, name='update_company'),
    path('delete/<int:company_id>', views.delete_company, name='update_company'),
    path('newtseller/', views.upload_newtseller, name='upload_newtseller'),
    path('ticketsellerall/', views.ticketseller_all, name='ticketseller_all'),
    path('approvetktseller/<int:tktseller_id>', views.approve_ticketseller, name='approve_ticketseller'),

]

if DEBUG:
    urlpatterns += static(STATIC_URL, document_root=STATIC_ROOT)
    urlpatterns += static(STATIC_URL, document_root=MEDIA_ROOT)
