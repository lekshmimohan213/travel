import sys
#print("Python version: {}".format(sys.version))
import pandas as pd
#print("pandas version: {}".format(pd.__version__))
import matplotlib
#print("matplotlib version: {}".format(matplotlib.__version__))
import numpy as np
from pandas.plotting import scatter_matrix
#print("NumPy version: {}".format(np.__version__))
import scipy as sp
#print("SciPy version: {}".format(sp.__version__))
import IPython
#print("IPython version: {}".format(IPython.__version__))
import sklearn
#print("scikit-learn version: {}".format(sklearn.__version__))


import matplotlib.pyplot as plt
"""
from tensorflow.keras.preprocessing.text import Tokenizer
from tensorflow.keras.preprocessing.sequence import pad_sequences
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import LSTM, Dense, Dropout, SpatialDropout1D
from tensorflow.keras.layers import Embedding
"""
def train():
    df = pd.read_csv("E:/PROJECT_2022/Musliar/project_chllenge/insurance/UP-Project-work-main/insuranceFraud_Dataset.csv")
    review_df = df[['incident_type','collision_type','incident_severity','authorities_contacted','police_report_available','bodily_injuries','fraud_reported']]
    print(review_df.shape)
    review_df = review_df[review_df['collision_type'] != '?']
    review_df = review_df[review_df['police_report_available'] != '?']
    print(review_df.shape)
    d_incident_type = {'Single Vehicle Collision': 0, 'Vehicle Theft': 1, 'Multi-vehicle Collision': 2,'Parked Car': 3}
    review_df['incident_type'] = review_df['incident_type'].map(d_incident_type)
    d_collision_type = {'Side Collision': 0, 'Rear Collision': 1, 'Front Collision': 2}
    review_df['collision_type'] = review_df['collision_type'].map(d_collision_type)
    d_collision_type = {'Side Collision': 0, 'Rear Collision': 1, 'Front Collision': 2}
    review_df['collision_type'] = review_df['collision_type'].map(d_collision_type)
    d_incident_severity = {'Major Damage': 0, 'Total Loss': 1, 'Minor Damage': 2, 'Trivial Damage': 3}
    review_df['incident_severity'] = review_df['incident_severity'].map(d_incident_severity)
    d_authorities= {'None': 0, 'Police': 1, 'Minor Damage': 2, 'Fire': 3,'Ambulance': 4}
    review_df['authorities_contacted'] = review_df['authorities_contacted'].map(d_authorities)
    d_police_available= {'NO': 0, 'YES': 1}
    review_df['police_report_available'] = review_df['police_report_available'].map(d_police_available)
    target=review_df['fraud_reported']
    del review_df['fraud_reported']
    feature_names=['incident_type','collision_type','incident_severity','authorities_contacted','police_report_available','bodily_injuries']
    print(review_df.shape)
    print("Keys of iris_dataset: \n{}".format(review_df.keys()))
    print("First five columns of data:\n{}".format(review_df['authorities_contacted'][:5]))
    targetnames = [1, 0]






    from sklearn.model_selection import train_test_split
    X_train, X_test, y_train, y_test = train_test_split(
    review_df, target, random_state=0)

    print("X_train shape: {}".format(X_train.shape))
    print("y_train shape: {}".format(y_train.shape))
    print("X_test shape: {}".format(X_test.shape))
    print("y_test shape: {}".format(y_test.shape))
    review_dataframe = pd.DataFrame(X_train, columns=feature_names)


















