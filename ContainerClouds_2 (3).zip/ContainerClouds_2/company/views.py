from django.contrib import messages
from django.shortcuts import render, redirect

from book.security import base64Encode
from company.sample4 import train
from .models import Company, TicketSeller
from .form import CompanyCreate, CreateTicketSeller
from django.http import HttpResponse


# Create your views here.
def admin_train(request):
    return render(request, 'train.html')

def admin_train_system(request):
    train()
    return render(request, 'trainresult.html')



def company_all(request):
    company = Company.objects.all()
    return render(request, 'list.html', {'company': company})

def ticketseller_all(request):
    ticketseller = TicketSeller.objects.all()
    return render(request, 'ticketsellers.html', {'tseller': ticketseller,'title':'Ticket Sellers List'})


def approve_ticketseller(request, tktseller_id):
    customer_id = int(tktseller_id)
    try:
        customer_shelf = TicketSeller.objects.get(id=customer_id)
    except TicketSeller.DoesNotExist:
        return redirect('ticketseller_all')
    customer_shelf.status = not customer_shelf.status
    cid = str(customer_shelf.id)
    key = base64Encode("tseller" + cid)
    customer_shelf.save(update_fields=['status'])
    f = open("demofile_ticket3.txt", "w")
    f.write("Your Key Is " + key)
    f.close()
    return  redirect('ticketseller_all')
    #return render(request, 'newcustomer.html', {'upload_form': customer_form, 'formname': ' Edit User'})


def upload_newtseller(request):
    upload = CreateTicketSeller()
    if request.method == 'POST':
        upload = CreateTicketSeller(request.POST, request.FILES)
        if upload.is_valid():
            user_na = upload.cleaned_data['username']
            if TicketSeller.objects.filter(username=user_na).exists():
                messages.error(request, 'Username Already Exist')
                return redirect('upload_newtseller')
            upload.save()
            messages.success(request, 'New Ticketseller created')
            return redirect('company_login')
        else:
            return HttpResponse(""" Something went wrong click <a href= "{{url: 'upload_newtseller'}}">Reload</a>""")
    else:
        return render(request, 'upload_form.html', {'upload_form': upload,'title':'TicketSeller SignUp'})

def upload(request):
    upload = CompanyCreate()
    if request.method == 'POST':
        upload = CompanyCreate(request.POST, request.FILES)
        if upload.is_valid():
            upload.save()
            return redirect('company_all')
        else:
            return HttpResponse(""" Something went wrong click <a href= "{{url: 'company_all'}}">Reload</a>""")
    else:
        return render(request, 'upload_form.html', {'upload_form': upload})


def update_company(request, company_id):
    company_id = int(company_id)
    try:
        company_shelf = Company.objects.get(id=company_id)
    except Company.DoesNotExist:
        return redirect('company_all')
    company_form = CompanyCreate(request.POST or None, instance=company_shelf)
    if company_form.is_valid():
        company_form.save()
        return redirect('company_all')
    return render(request, 'upload_form.html', {'upload_form': company_form})


def delete_company(request, company_id):
    company_id = int(company_id)
    try:
        company_shelf = Company.objects.get(id=company_id)
    except Company.DoesNotExist:
        return redirect('company_all')
    company_shelf.delete()
    return redirect('company_all')
