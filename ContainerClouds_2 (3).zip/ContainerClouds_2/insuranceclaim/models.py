from django.db import models


# Create your models here.

class InsuranceClaim(models.Model):

    PolicyNumber = models.CharField(max_length=50)
    Monthascustomer = models.IntegerField()
    Policydate = models.DateField()
    Policydate = models.CharField(max_length=50)
    PolicyDeductable = models.IntegerField()
    PolicyAnnualPremium = models.IntegerField()
    Occupation = models.CharField(max_length=50)
    Eduction = models.CharField(max_length=50)
    Capitalloss = models.IntegerField()
    IncidentDate = models.DateField()
    IncidentHour = models.CharField(max_length=50)
    IncidentType = models.CharField(max_length=50)
    CollisionType = models.CharField(max_length=50)
    IncidentSeverity = models.CharField(max_length=50)
    AuthorityContact =  models.CharField(max_length=50)
    IncidentState = models.CharField(max_length=50)
    IncidentCity= models.CharField(max_length=50)
    IncidentLocation= models.CharField(max_length=50)
    NumberofVehiclesInvolved =models.CharField(max_length=50)
    PropertyDamage = models.CharField(max_length=50)
    BadilyInjuries = models.IntegerField(max_length=50)
    Witness = models.IntegerField(max_length=50)
    PoliceReportAvailable =models.CharField(max_length=50)
    TotalClaimAmount = models.IntegerField(max_length=50)
    InjuryClainAmount =models.IntegerField(max_length=50)
    PropertyClainAmount = models.IntegerField(max_length=50)
    VehicleClimAmoun =models.IntegerField(max_length=50)

    def __str__(self):
        return self.PolicyNumber


"""

['incident_type','collision_type','incident_severity','authorities_contacted','police_report_available','bodily_injuries']

----------------------------

incident_type

Single Vehicle Collision
Vehicle Theft
Multi-vehicle Collision
Parked Car

------------------------------
collision_type

Side Collision
Rear Collision
Front Collision

------------------------------
incident_severity

Major Damage
Total Loss
Minor Damage
Trivial Damage
-----------------------------------------------
authorities_contacted

Police
None
Fire
Ambulance

---------------------------------------------
police_report_available

YES
NO
--------------------------------------------------
bodily_injuries



"""