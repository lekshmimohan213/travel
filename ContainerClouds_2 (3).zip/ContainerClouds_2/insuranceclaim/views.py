
from django.shortcuts import render, redirect
from .form import InsuranceClaimCreate
from django.http import HttpResponse
# Create your views here.




def upload_claim(request):
    upload = InsuranceClaimCreate()
    if request.method == 'POST':
        upload = InsuranceClaimCreate(request.POST, request.FILES)
        if upload.is_valid():
            upload.save()
            return redirect('product_all')
        else:
            return HttpResponse(""" Something went wrong click <a href= "{{url: 'product_all'}}">Reload</a>""")
    else:
        return render(request, 'upload_form.html', {'upload_form': upload})  #need to change