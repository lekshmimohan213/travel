from django.urls import path
from . import views
from abclibrary.settings import DEBUG, STATIC_URL, STATIC_ROOT, MEDIA_URL, MEDIA_ROOT
from django.conf.urls.static import static

urlpatterns = [
    path('uploadclaim', views.upload_claim, name='upload_claim'),
    #path('', views.index, name='index'),
    # path('booksall', views.books_all, name='books_all'),
    # path('staffbooksall', views.books_staff_all, name='books_staff_all'),
    # path('staffgiveacess', views.books_staff_ticket, name='books_staff_ticket'),
    # path('staffacees/<int:book_id>', views.books_staff_acess, name='books_staff_acess'),
    # path('booksaccess/<int:book_id>', views.books_access, name='books_access'),
    # path('upload/', views.upload, name='upload_book'),
    # path('upload/<int:book_id>', views.update_book, name='update_book'),
    # path('delete/<int:book_id>', views.delete_book, name='delete_book'),
    # path('bookshaveaccess/', views.books_hve_access, name='books_have_access'),
    # path('permituser/<int:reqid>', views.permit_user, name='permit_user'),
    # path('uploadkeymessage/<int:book_id>', views.update_key_message, name='getkey_update_message'),
    # path('downloadfile/<int:path>', views.download_file, name='download_file'),
]


