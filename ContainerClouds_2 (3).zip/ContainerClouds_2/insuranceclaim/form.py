from django import forms
from .models import InsuranceClaim


class InsuranceClaimCreate(forms.ModelForm):
    class Meta:
        model = InsuranceClaim
        fields = '__all__'
        #widgets = {'filename': forms.FileField}
